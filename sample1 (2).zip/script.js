const urlParams = new URLSearchParams(window.location.search);
const storyId = urlParams.get('storyId');
console.log("Story ID: ", storyId); // Check the value of storyId

// Default to story1 if no storyId is provided
const storyFile = `stories/story${storyId || 1}.json`;

fetch(storyFile)
  .then(response => {
    if (!response.ok) {
      throw new Error('Story file not found');
    }
    return response.json();
  })
  .then(data => {
    const totalPages = data.pages.length;
    document.getElementById('total-pages').textContent = totalPages;

    // Load the first page
    loadPage(0, data);

    let currentPage = 0;

    // Previous and Next buttons
    document.getElementById('prev-btn').addEventListener('click', () => {
      if (currentPage > 0) {
        loadPage(--currentPage, data);
      }
    });

    document.getElementById('next-btn').addEventListener('click', () => {
      if (currentPage < totalPages - 1) {
        loadPage(++currentPage, data);
      }
    });

    function loadPage(pageIndex, storyData) {
      const page = storyData.pages[pageIndex];
      document.getElementById('page-image').src = page.image;
      document.getElementById('page-text').textContent = page.text || ''; // Assuming the page has text
      document.getElementById('current-page').textContent = pageIndex + 1;

      // Audio setup
      const pageSound = document.getElementById('page-sound');
      const bgMusic = document.getElementById('bg-music');
      const narration = document.getElementById('narration');

      // Set page-specific sound (e.g., page turn sound)
      pageSound.src = page.sound;
      pageSound.play();

      // Set background music
      if (page.bgMusic) {
        bgMusic.src = page.bgMusic;
        bgMusic.volume = page.bgMusicVolume || 0.5;
        bgMusic.play();
      }

      // Set narration (if available)
      if (page.narration) {
        narration.src = page.narration;
        narration.volume = page.narrationVolume || 1;
        narration.play();
      }
    }
  })
  .catch(error => {
    console.error('Error loading story:', error);
  });