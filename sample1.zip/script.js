fetch('story.json')
  .then((response) => response.json())
  .then((data) => {
    const pages = data;
    let currentPage = 0;

    // DOM elements
    const pageImage = document.getElementById("page-image");
    const pageSound = document.getElementById("page-sound");
    const bgMusic = document.getElementById("bg-music");
    const prevBtn = document.getElementById("prev-btn");
    const nextBtn = document.getElementById("next-btn");
    const currentPageIndicator = document.getElementById("current-page");
    const totalPagesIndicator = document.getElementById("total-pages");

    // Narration audio element
    const narrationAudio = new Audio();

    // Display total pages
    totalPagesIndicator.textContent = pages.length;

    // State to check if audio can be played
    let isUserInteracted = false;

    // Function to set narration volume
    function setNarrationVolume(volume) {
      narrationAudio.volume = volume; // Set volume (0 to 1)
    }

    // Function to set background music volume
    function setBackgroundMusicVolume(volume) {
      bgMusic.volume = volume; // Set volume (0 to 1)
    }

    // Function to load a page
    function loadPage(index) {
  const page = pages[index];

  // Update page image
  pageImage.src = page.image;

  // Reset background music and narration
  bgMusic.src = page.bgMusic;
  narrationAudio.src = page.narration;

  // Set audio volumes
  setBackgroundMusicVolume(page.bgMusicVolume || 0.5);
  setNarrationVolume(page.narrationVolume || 1);

  // Stop any currently playing audio
  bgMusic.pause();
  narrationAudio.pause();
  bgMusic.currentTime = 0;
  narrationAudio.currentTime = 0;

  // For all pages, ensure narration plays first
  if (isUserInteracted) {
    narrationAudio.play()
      .then(() => {
        console.log("Narration started");

        // Listen for narration's `ended` event
        narrationAudio.onended = () => {
          console.log("Narration ended");

          // Wait for 3 seconds before stopping the background music
          setTimeout(() => {
            bgMusic.pause();
            bgMusic.currentTime = 0; // Reset background music after 3 seconds
            console.log("Background music stopped after 1 seconds");
          }, 1000); // Delay background music stop for 1 seconds

          // Enable user to proceed to the next page after delay
          console.log("Waiting for user to proceed...");
        };

        // Play background music simultaneously (optional for specific pages)
        if (index !== 0 && index !== 2  && index !== 3) { // Example: No delays for pages 0 and 2
          bgMusic.play().catch((error) => {
            console.error("Error playing background music:", error);
          });
        }
      })
      .catch((error) => {
        console.error("Error playing narration:", error);
      });
  }

// Handle special delays for Page 1, Page 3, and Page 4
if (index === 0) {
  bgMusic.play()
    .then(() => {
      setTimeout(() => {
        bgMusic.pause();
        bgMusic.currentTime = 0; // Reset background music after 5 seconds
      }, 5000); // 5-second delay for Page 1
    })
    .catch((error) => console.error("Error playing background music:", error));
} else if (index === 2) {
  setTimeout(() => {
    bgMusic.play().catch((error) => console.error("Error playing background music:", error));
  }, 1000); // 1-second delay for background music on Page 3
} else if (index === 3) { // Added delay for Page 4
  setTimeout(() => {
    bgMusic.play().catch((error) => console.error("Error playing background music:", error));
  }, 1000); // 1-second delay for background music on Page 4
}
  // Play page turn sound
  playPageTurnSound();

  // Update progress indicator
  currentPageIndicator.textContent = index + 1;
}

    // Function to play the page turn sound
    function playPageTurnSound() {
      pageSound.src = pages[currentPage].sound;
      pageSound.currentTime = 0;
      pageSound.loop = false; // Ensure the sound does not loop
      pageSound.play().catch((error) => {
        console.error("Error playing page turn sound:", error);
      });
    }

    // Event listener to mark user interaction
    function markUserInteraction() {
      isUserInteracted = true;
    }

    // Navigation buttons
    prevBtn.onclick = () => {
      markUserInteraction();
      if (currentPage > 0) {
        currentPage--;
        loadPage(currentPage);
      }
    };

    nextBtn.onclick = () => {
      markUserInteraction();
      if (currentPage < pages.length - 1) {
        currentPage++;
        loadPage(currentPage);
      }
    };

    // Ensure interaction is captured when the page loads
    document.body.addEventListener("click", markUserInteraction, { once: true });

    // Load the first page on startup
    loadPage(currentPage);
  })
  .catch((error) => console.error("Error loading the story JSON:", error));
  