// Get the storyId from the URL
const urlParams = new URLSearchParams(window.location.search);
const storyId = urlParams.get('storyId');
console.log(storyId); // Make sure this is not null or undefined

fetch('story.json')
  .then(response => {
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    return response.json();
  })
  .then(stories => {
    console.log(stories); // Check if stories are correctly loaded
    // Find the story with the matching ID
    const story = stories.find(story => story.storyId == storyId); // Compare the storyId as string

    if (!story) {
      console.error("Story not found");
      return;
    }

    let currentPage = localStorage.getItem('currentPage') ? parseInt(localStorage.getItem('currentPage')) : 0; // Load saved page

    // DOM elements
    const pageImage = document.getElementById("page-image");
    const pageSound = document.getElementById("page-sound");
    const bgMusic = document.getElementById("bg-music");
    const narrationAudio = new Audio();
    const prevBtn = document.getElementById("prev-btn");
    const nextBtn = document.getElementById("next-btn");
    const audioToggleBtn = document.getElementById("audio-toggle-btn");
    const currentPageIndicator = document.getElementById("current-page");
    const totalPagesIndicator = document.getElementById("total-pages");
    const storyTitle = document.getElementById("story-title");
    const loadingIndicator = document.getElementById("loading"); // Add a loading indicator element
    let audioEnabled = true;

    // Functions for volume control
    function setNarrationVolume(volume) {
      narrationAudio.volume = volume;
    }

    function setBackgroundMusicVolume(volume) {
      bgMusic.volume = volume;
    }

    // Preload media for a page (audio files)
    function preloadMedia(mediaArray) {
      mediaArray.forEach((src) => {
        const media = new Audio(src); // Preload the audio files
        media.preload = "auto";
      });
    }

    // Show and hide loading indicator
    function showLoading() {
      loadingIndicator.style.display = "block";
    }

    function hideLoading() {
      loadingIndicator.style.display = "none";
    }

    // Function to load the current page
    function loadPage(pageIndex) {
      showLoading();
      const page = story.pages[pageIndex];

      // Set image and sound for the page
      pageImage.style.opacity = 0; // Fade out the image
      pageImage.src = page.image;
      bgMusic.src = page.bgMusic;
      narrationAudio.src = page.narration;

      setBackgroundMusicVolume(page.bgMusicVolume || 0.5);
      setNarrationVolume(page.narrationVolume || 1);

      bgMusic.pause();
      narrationAudio.pause();
      bgMusic.currentTime = 0;
      narrationAudio.currentTime = 0;

      // Preload the audio for this page
      preloadMedia([narrationAudio.src, bgMusic.src]);

      // Ensure audio is only played after user interaction
      if (audioEnabled) {
        if (narrationAudio.src) {
          narrationAudio.play().catch((error) => console.error("Error playing narration:", error));
        }
        if (bgMusic.src) {
          bgMusic.play().catch((error) => console.error("Error playing background music:", error));
        }
      }

      // Fade in the image after setting the src
      setTimeout(() => {
        pageImage.style.opacity = 1;
      }, 500); // Adjust time to control fade-in speed

      playPageTurnSound();

      // Update page indicators
      currentPageIndicator.textContent = pageIndex + 1;
      totalPagesIndicator.textContent = story.pages.length;
      storyTitle.textContent = story.title;

      // Stop background music after narration ends
      narrationAudio.onended = () => {
        setTimeout(() => {
          bgMusic.pause();
        }, 2000); // Stop background music 2 seconds after narration finishes
      };

      // Update navigation buttons
      updateNavigationButtons();

      hideLoading(); // Hide loading indicator once the page is loaded
    }

    // Play the page turn sound
    function playPageTurnSound() {
      pageSound.src = story.pages[currentPage].sound;
      pageSound.currentTime = 0;
      pageSound.loop = false;
      pageSound.play().catch((error) => console.error("Error playing page turn sound:", error));
    }

    // Update navigation buttons state
    function updateNavigationButtons() {
      prevBtn.disabled = currentPage === 0;
      nextBtn.disabled = currentPage === story.pages.length - 1;
    }

    // Toggle audio on/off
    audioToggleBtn.addEventListener("click", () => {
      audioEnabled = !audioEnabled;

      if (audioEnabled) {
        audioToggleBtn.textContent = "🔊 Audio On";
        if (narrationAudio.src) {
          narrationAudio.play().catch((error) => console.error("Error resuming narration:", error));
        }
        if (bgMusic.src) {
          bgMusic.play().catch((error) => console.error("Error resuming background music:", error));
        }
      } else {
        audioToggleBtn.textContent = "🔇 Audio Off";
        narrationAudio.pause();
        bgMusic.pause();
      }
    });

    // Previous button click event
    prevBtn.addEventListener("click", () => {
      if (currentPage > 0) {
        currentPage--;
        loadPage(currentPage);
      }
    });

    // Next button click event
    nextBtn.addEventListener("click", () => {
      if (currentPage < story.pages.length - 1) {
        currentPage++;
        loadPage(currentPage);
      }
    });

    // Initial page load
    loadPage(currentPage);

    // Save the user's progress to localStorage
    window.localStorage.setItem('currentPage', currentPage);

  })
  .catch(error => {
    console.error("Error loading the story JSON:", error);
  });